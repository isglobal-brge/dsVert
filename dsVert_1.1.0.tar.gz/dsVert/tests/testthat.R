# This file is part of the standard testthat testing infrastructure
library(testthat)
library(dsVert)

test_check("dsVert")
